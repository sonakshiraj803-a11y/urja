/**
 * Shared contract between the React app (src/) and the Ask URJA AI server (server/).
 * Both sides import from this file, so a change here is checked on both sides by TypeScript.
 */

/** Phase 1 teaches one lesson. The server decides the real syllabus; the client only names it. */
export const LESSON_ID = 'physics-11-laws-of-motion-inertia' as const
export type LessonId = typeof LESSON_ID

export const TEACHING_APPROACHES = [
  'Explain from basics',
  'Conceptual deep dive',
  'Examples first',
  'Exam-oriented',
] as const
export type TeachingApproach = (typeof TEACHING_APPROACHES)[number]

export const LANGUAGES = ['English', 'Hindi', 'Hinglish'] as const
export type LessonLanguage = (typeof LANGUAGES)[number]

/** Limits enforced by the server. The client uses questionMax for the textarea. */
export const LIMITS = {
  /** Longest question a student can send, in characters. */
  questionMax: 1200,
  /** Most earlier turns the server accepts with one question. */
  historyMax: 8,
  /** Longest single earlier turn, in characters (an assistant turn is a whole flattened reply). */
  historyItemMax: 6000,
  /** Longest text the server will turn into speech, in characters. */
  speechTextMax: 5500,
  /** Requests per IP per minute, shared by chat and voice. */
  requestsPerMinute: 12,
  /** Largest request body the server reads, in bytes. */
  bodyMax: 100_000,
} as const

/** What the student picked on the lesson setup screen. */
export type LessonPrefs = {
  teachingApproach: TeachingApproach
  language: LessonLanguage
}

/** A structured answer from URJA AI. Empty strings and empty arrays mean "not used". */
export type UrjaReply = {
  explanation: string
  steps: string[]
  example: string
  takeaway: string
  followUp: string
}

export type HistoryTurn = {
  role: 'user' | 'assistant'
  content: string
}

/** One message in the chat thread. Assistant messages keep the structured reply for display. */
export type ChatMessage =
  | { role: 'user'; content: string }
  | { role: 'assistant'; content: string; reply: UrjaReply }

/** Body of POST /api/urja */
export type AskUrjaRequest = {
  lessonId: LessonId
  teachingApproach: TeachingApproach
  language: LessonLanguage
  question: string
  history: HistoryTurn[]
}

/** 200 response of POST /api/urja */
export type AskUrjaResponse = {
  reply: UrjaReply
  /** The reply flattened to plain text. Stored in history so follow-ups have context. */
  text: string
}

/** Body of POST /api/urja/voice. The 200 response is raw audio, not JSON. */
export type SpeechRequest = {
  text: string
  language: LessonLanguage
}

/** Every non-200 response from /api/urja and /api/urja/voice. The message is safe to show students. */
export type ApiErrorBody = {
  error: string
}

/** Flattens a structured reply into the plain text used as conversation history. */
export function replyToText(reply: UrjaReply): string {
  return [
    reply.explanation,
    ...reply.steps.map((step, index) => `${index + 1}. ${step}`),
    reply.example ? `Example: ${reply.example}` : '',
    reply.takeaway ? `Remember: ${reply.takeaway}` : '',
    reply.followUp,
  ]
    .filter(Boolean)
    .join('\n')
}
