import type { AskUrjaRequest, AskUrjaResponse, ApiErrorBody, SpeechRequest, UrjaReply } from './contract'

/**
 * Browser client for the Ask URJA AI server routes.
 * The Gemini key never reaches the browser: these calls only talk to /api/urja on our own server.
 */

const CHAT_URL = '/api/urja'
const VOICE_URL = '/api/urja/voice'

/** The server may retry across models for up to about 50 seconds, so wait a little longer than that. */
const CHAT_TIMEOUT_MS = 70_000
const VOICE_TIMEOUT_MS = 60_000

const FALLBACK_ERROR = 'URJA AI could not answer just now. Please try again.'
const NETWORK_ERROR = 'URJA AI could not be reached. Check that the app is running and your internet is on, then try again.'
const TIMEOUT_ERROR = 'URJA AI is taking too long. Please try again in a moment.'
const UNREADABLE_ERROR = 'URJA AI sent an answer that could not be read. Please ask once more.'

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null
}

function isStringArray(value: unknown): value is string[] {
  return Array.isArray(value) && value.every(item => typeof item === 'string')
}

function isUrjaReply(value: unknown): value is UrjaReply {
  return isRecord(value)
    && typeof value.explanation === 'string'
    && isStringArray(value.steps)
    && typeof value.example === 'string'
    && typeof value.takeaway === 'string'
    && typeof value.followUp === 'string'
}

function isAskUrjaResponse(value: unknown): value is AskUrjaResponse {
  return isRecord(value) && isUrjaReply(value.reply) && typeof value.text === 'string'
}

function isApiErrorBody(value: unknown): value is ApiErrorBody {
  return isRecord(value) && typeof value.error === 'string' && value.error.length > 0
}

/** Reads the server's student-safe error message, or falls back to a generic one. */
async function readError(response: Response): Promise<string> {
  try {
    const body: unknown = await response.json()
    if (isApiErrorBody(body)) return body.error
  } catch {
    // The body was not JSON, so use the generic message below.
  }
  return FALLBACK_ERROR
}

async function post(url: string, payload: unknown, timeoutMs: number): Promise<Response> {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)
  try {
    return await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      signal: controller.signal,
    })
  } catch (error) {
    if (error instanceof DOMException && error.name === 'AbortError') {
      throw new Error(TIMEOUT_ERROR)
    }
    throw new Error(NETWORK_ERROR)
  } finally {
    clearTimeout(timer)
  }
}

/** Ask the tutor one question. Throws an Error whose message is safe to show the student. */
export async function askUrja(request: AskUrjaRequest): Promise<AskUrjaResponse> {
  const response = await post(CHAT_URL, request, CHAT_TIMEOUT_MS)
  if (!response.ok) throw new Error(await readError(response))

  let body: unknown
  try {
    body = await response.json()
  } catch {
    throw new Error(UNREADABLE_ERROR)
  }
  if (!isAskUrjaResponse(body)) throw new Error(UNREADABLE_ERROR)
  return body
}

/** Turn a tutor reply into spoken audio. Resolves to an audio Blob the page can play. */
export async function synthesizeUrjaVoice(request: SpeechRequest): Promise<Blob> {
  const response = await post(VOICE_URL, request, VOICE_TIMEOUT_MS)
  if (!response.ok) throw new Error(await readError(response))

  const audio = await response.blob()
  if (audio.size === 0) throw new Error('URJA AI could not prepare the spoken reply. Please try again.')
  return audio
}
